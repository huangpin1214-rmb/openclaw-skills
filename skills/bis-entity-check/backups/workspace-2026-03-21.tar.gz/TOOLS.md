# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

### 创建新 Skill 规范

以后创建新 Skill 时，必须同时完成：

1. ✅ 创建 `SKILL.md` 文档
2. ✅ 创建 `scripts/` 目录和脚本
3. ✅ 更新 `README.md`
4. ✅ 更新 `memory/YYYY-MM-DD.md`
5. ⚠️ **先测试功能正常后，再推送到 GitHub（等用户确认）**
6. ⚠️ **新增或迭代的skill，需要得到用户确认后再推送**

---

### Get 笔记

- API Key: gk_live_d6b346daab8c1120.695c91212fb3dc706bb893e4f77daa54e9207d83ddd29047
- Client ID: cli_3802f9db08b811f197679c63c078bacc

---

Add whatever helps you do your job. This is your cheat sheet.

### 版本检查标准流程

当有人问"XX 技能/工具是否最新"时，必须按以下步骤验证：

1. **查本地版本** → `cat package.json | grep version` 或 `git log -1 --oneline`
2. **查远程真实版本** → `git fetch && git log origin/master -1 --oneline`
3. **对比** → 不一致才需要更新，一致则报"已是最新"

⚠️ 禁止直接相信 clawdhub/工具返回的版本号，必须用 git 交叉验证！

### 网络搜索技巧

- **web_fetch**: 当 curl/brave-search 超时时，尝试用这个工具（不走 WSL 代理）

### 铁律：不确定就闭嘴

**输出任何信息前，必须过一遍**：

1. ❓ 这个信息是**100%确定**的吗？
   - 是 → 输出
   - 否/不知道 → 跳到下一步

2. ⚠️ 如果不确定，应该：
   - 直接说"查不到"、"不确定"
   - 绝对不能**猜**、**推算**、**估计**
   - 绝对不能说"大概"、"可能"、"应该是"

3. 🎯 正确示范：
   - ❌ "大约21点到"
   - ✅ "查不到具体时刻，建议看12306 App"

**宁可不说，绝不说错**。
