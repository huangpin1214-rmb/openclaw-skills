# USER.md - About Your Human

- **Name:** 频哥
- **What to call them:** 频哥
- **Pronouns:** 
- **Timezone:** Asia/Shanghai
- **Location:** 成都
- **Occupation:** 芯片公司 - 质量运营与IT管理主管
- **Interests:** 
  - AI技术发展与应用（非常感兴趣）
- **Notes:**
  - 记笔记默认存到 Get笔记
  - 常驻地：成都
