# HEARTBEAT.md

# Heartbeat 检查清单

## 定期任务（每周几次）

### 1. BIS 官网学习（每周 2-3 次）
- 访问 https://www.bis.gov/regulations/federal-register-notices
- 检查最近一周的 EAR 法规更新
- 记录重要更新到知识库

### 2. 实体清单检查（每周）
- 检查是否有新增中国实体
- 更新 bis-entity-check 技能的公司数据库

### 3. 学习笔记
- 将新学到的政策/法规变化记录下来
- 更新 SKILL.md 或 docs/ 中的知识库

---

# 快速检查（每 2-3 天）

- 邮件检查
- 日历检查
- 待处理任务