# PCIe (PCI Express) 全面学习笔记

> 整理自 YouTube 教程视频及技术文档
> 来源: Hardware Whisperer, ChipMonk Masterclass, RidgeRun, LinkedIn 等

---

## 一、PCIe 概述

### 1.1 什么是 PCIe？

**PCIe (Peripheral Component Interconnect Express)** - 外围组件互连 Express，是一种高速串行计算机扩展总线标准。

- **创建时间**: 2004年
- **创建者**: Intel、Dell、HP、IBM
- **取代**: AGP、PCI、PCI-X

### 1.2 为什么需要 PCIe？

**前身问题**:
- PCI 是并行总线 → 速度受限，Pin 脚多
- PCI-X 虽有改进，但并行架构限制速度提升
- 需要更高带宽来支持显卡、NVMe SSD 等高速设备

**PCIe 解决方案**:
- 采用**串行点对点**架构 (不再共享总线)
- 支持多 lanes 并行扩展
- 差分信号传输，抗干扰能力强

---

## 二、PCIe 核心概念

### 2.1 Lane (通道)

- **定义**: 每个 lane 是一对差分线 (TX+TX- 和 RX+RX-)
- **功能**: 独立的双向数据传输通道
- **配置**: x1, x2, x4, x8, x12, x16, x32

```
x1   → 1 lane  (最短)
x4   → 4 lanes
x8   → 8 lanes  
x16  → 16 lanes (最长，常见于显卡插槽)
x32  → 32 lanes
```

### 2.2 Slot (插槽) 大小

| 插槽类型 | Lane 数量 | 典型用途 |
|---------|----------|---------|
| x1 | 1 | 网卡、声卡 |
| x4 | 4 | NVMe SSD |
| x8 | 8 | RAID 卡 |
| x16 | 16 | 显卡 |

### 2.3 双向通信 (Dual Simplex)

- PCIe 采用 **dual-simplex** 而非全双工
- 每个 lane 有独立的发送和接收对
- 可以同时进行发送和接收

---

## 三、PCIe 版本与带宽

### 3.1 带宽演进

| 版本 | 传输速率 | 每 Lane 带宽 | x16 带宽 | 编码方式 |
|-----|---------|-------------|---------|---------|
| PCIe 1.0 | 2.5 GT/s | 250 MB/s | 4 GB/s | 8b/10b |
| PCIe 2.0 | 5 GT/s | 500 MB/s | 8 GB/s | 8b/10b |
| PCIe 3.0 | 8 GT/s | 985 MB/s | 15.75 GB/s | 128b/130b |
| PCIe 4.0 | 16 GT/s | 1.97 GB/s | 31.5 GB/s | 128b/130b |
| PCIe 5.0 | 32 GT/s | 3.94 GB/s | 63 GB/s | 128b/130b |
| PCIe 6.0 | 64 GT/s | 7.88 GB/s | 126 GB/s | PAM4 + 128b/130b |
| PCIe 7.0 | 128 GT/s | ~15.8 GB/s | ~252 GB/s | (即将推出) |

> GT/s = Gigatransfers per second (每秒吉比特传输)
> GB/s = Gigabytes per second (每秒吉字节)

### 3.2 带宽计算

**公式**: `带宽 = 传输速率 × 编码效率 × Lane数`

- PCIe 3.0 x16: `8 GT/s × (128/130) × 16 ≈ 15.75 GB/s`

---

## 四、PCIe 协议栈架构

PCIe 采用**三层架构**:

```
┌─────────────────────────────────────┐
│         Transaction Layer           │  ← 事务层
├─────────────────────────────────────┤
│          Data Link Layer            │  ← 数据链路层
├─────────────────────────────────────┤
│          Physical Layer             │  ← 物理层
└─────────────────────────────────────┘
```

### 4.1 物理层 (Physical Layer)

**职责**:
- 电气信号传输
- 串行化/反串行化
- 链路初始化和训练
- 电源状态管理

**子层**:
- **PHY**: 电气信号处理
- **MAC**: 逻辑部分 - 成帧、编码、调度

**关键特性**:
- 差分信号对
- 8b/10b (Gen1/Gen2) / 128b/130b (Gen3+) 编码
- 眼图测试
- 均衡 (Equalization)

### 4.2 数据链路层 (Data Link Layer)

**职责**:
- 流量控制 (Flow Control)
- 错误检测
- ACK/NAK 确认
- 电源管理

**关键机制**:
- **ACK/NAK**: 可靠传输协议
- **CRC**: 错误检测
- **Sequence Number**: 帧编号

### 4.3 事务层 (Transaction Layer)

**职责**:
- TLP (Transaction Layer Packet) 创建/解码
- 寻址和路由
- 虚拟通道 (Virtual Channel) 和 QoS
- 读/写/完成事务处理

**TLP 类型**:

| TLP 类型 | 功能 |
|---------|-----|
| Memory Read | 读取内存 |
| Memory Write | 写入内存 |
| I/O Read/Write | 旧式 I/O (现代少见) |
| Configuration Read/Write | 设备配置 |
| Message | 消息/中断 |
| Completion | 读响应 |

**地址空间**:
- Memory Space: 设备内存、MMIO 寄存器
- I/O Space: 传统 I/O (现代少用)
- Configuration Space: 设备发现和配置

---

## 五、PCIe 拓扑结构

### 5.1 核心组件

```
┌─────────────┐
│     CPU     │
└──────┬──────┘
       │
┌──────▼──────┐
│ Root Complex │  ← CPU/芯片组接口
│     (RC)     │
└──────┬──────┘
       │
┌──────▼──────┐
│    Switch    │  ← 交换器
└──────┬──────┘
  │    │    │
┌▼┐  ┌▼┐  ┌▼┐
│ │  │ │  │ │
EP EP EP    EP
(Endpoint - 终端设备)
```

- **Root Complex (RC)**: CPU/芯片组端
- **Endpoint (EP)**: 外围设备 (显卡、网卡、SSD)
- **Switch**: 扩展多个端口

### 5.2 上游/下游

- **Upstream**: 设备 → RC (CPU方向)
- **Downstream**: RC (CPU) → 设备

---

## 六、关键特性

### 6.1 向后兼容性

- PCIe 设备可在旧版本插槽中运行
- 速度降级到插槽支持的版本
- 软件层面完全兼容 PCI

### 6.2 虚拟通道 (Virtual Channels)

- 支持最多 8 个虚拟通道 (VC0-VC7)
- 映射到 Traffic Class (TC0-TC7)
- 实现 QoS，防止头端阻塞

### 6.3 MSI (Message Signaled Interrupts)

- 中断通过 TLP 发送
- 无需共享中断线
- 支持多个中断源

---

## 七、M.2 和 PCIe

### 7.1 M.2 插槽

- M.2 使用 PCIe lanes 连接 NVMe SSD
- 常见: x2 或 x4 配置
- 支持 AHCI 或 NVMe 协议

### 7.2 NVMe over PCIe

- NVMe 协议直接通过 PCIe 传输
- 相比 SATA 大幅降低延迟

---

## 八、学习要点总结

### 核心必须掌握:

1. ✅ **Lane 概念**: x1/x4/x8/x16 区别
2. ✅ **带宽计算**: 各版本速率和编码方式
3. ✅ **三层架构**: 物理层/数据链路层/事务层
4. ✅ **TLP**: 事务层数据包类型
5. ✅ **差分信号**: 抗干扰原理
6. ✅ **向后兼容性**: 版本兼容规则

### 进阶 topics:

- 信号完整性 (眼图、均衡)
- PCIe 切换和路由
- DMA 和地址空间
- 虚拟化 (SR-IOV, PASID)

---

## 九、推荐学习资源

- **视频**: Hardware Whisperer - PCIe Explained
- **视频**: ChipMonk PCIe Masterclass
- **文档**: Xilinx PG156 (UltraScale PCIe)
- **文档**: PCI-SIG 官方规范

---

*笔记整理时间: 2026-03-22*
