# PCIe (PCI Express) 完整学习笔记

> 学习日期：2026-03-22
> 主要来源：Xillybus PCIe Tutorial, SNIA Webinar, SoC & FPGA PCIe Gen6 教程

---

## 一、PCIe 概述

### 1.1 什么是 PCIe？

**PCIe (Peripheral Component Interconnect Express)** 是一种用于连接计算机组件的高速串行计算机扩展总线标准。

**关键点：PCIe 不是传统意义上的总线**

- 传统 PCI 是**并行总线**，多设备共享同一组物理线路
- PCIe 是**点对点(packet-based network)**，每个设备有独立连接到交换机
- 更像以太网交换机，而非传统PCI/PCI-X总线
- 设计上仍然模拟传统 PCI 行为，对操作系统透明

### 1.2 物理连接

**最小 PCIe 1x 连接仅需 6 根线：**
- 2对差分线用于数据传输（发送+接收）
- 1对线提供参考时钟
- 电源和地线

### 1.3 代际演进

| 世代 | 传输速率(x1) | 频率 |
|------|-------------|------|
| Gen1 | 250 MB/s | 2.5 GT/s |
| Gen2 | 500 MB/s | 5 GT/s |
| Gen3 | 1 GB/s | 8 GT/s |
| Gen4 | 2 GB/s | 16 GT/s |
| Gen5 | 4 GB/s | 32 GT/s |
| Gen6 | 8 GB/s | 64 GT/s |
| Gen7 | 16 GB/s | 128 GT/s (规划中) |

---

## 二、PCIe 协议栈 (三层架构)

PCIe 采用三层结构，每层负责不同功能：

### 2.1 事务层 (Transaction Layer)

**核心功能：** 生成和处理事务层数据包 (TLP)

**主要职责：**
- 接收来自软件层的读写请求
- 构造 TLP 包
- 端到端的流量控制
- 支持的 TLP 类型：
  - Memory Read/Write Request
  - I/O Read/Write Request (兼容性保留)
  - Configuration Read/Write Request
  - Completion (响应读请求)
  - Message (中断、功耗管理等)

**TLP 格式：**
```
[TLP Header] [Data Payload] [TLP Digest (可选)]
```

**Header 格式 (3DW 或 4DW)：**
- Fmt[2:0] - 格式 (读/写请求、带不带数据等)
- Type[4:0] - 包类型
- TD - TLP Digest 存在位
- EP - 错误传播
- Attr[2:0] - 属性 (relaxed ordering, no snoop, priority)
- TC[2:0] - 流量类别
- Length[9:0] - 数据长度 (DW单位)

### 2.2 数据链路层 (Data Link Layer)

**核心功能：** 确保 TLP 可靠传输

**主要职责：**
- 为 TLP 添加链路 CRC (LCRC)
- 端到端的确认/重传机制 (Ack/Nack)
- 流量控制 (Flow Control)
- 生成 DLLP (Data Link Layer Packets)

**DLLP 类型：**
- Ack/Nack - 确认/否认
- Flow Control (InitFC1, InitFC2, UpdateFC)
- Power Management

**流量控制机制：**
- 6 种信用类型：
  1. Posted Request Header
  2. Posted Request Data
  3. Non-Posted Request Header
  4. Non-Posted Request Data
  5. Completion Header
  6. Completion Data
- 基于 16 字节的流量控制单元 (FC Unit)
- 交换机每条链路独立维护流量控制

### 2.3 物理层 (Physical Layer)

**核心功能：** 物理信号传输

**主要职责：**
- 编码/解码 (8b/10b for Gen1-5, 128b/130b for Gen6+)
- 串行/并行转换
- 链路训练和状态机 (LTSSM)
- 物理层Ordered Set

---

## 三、PCIe 拓扑结构

### 3.1 核心组件

**Root Complex (RC / 根Complex)**
- CPU/内存控制器与 PCIe 世界的接口
- 发起和接收读写请求
- 相当于 PCIe 网络的"起点"

**Endpoint (EP / 端点)**
- PCIe 设备 (显卡、网卡、SSD等)
- 作为请求的发起者(Requester)或完成者(Completer)

**Switch (交换机)**
- 多个 PCIe 端口的互连
- 路由 TLP 包
- 支持虚拟通道 (Virtual Channels)

**Bridge (桥接)**
- PCIe 到 PCI/PCI-X 桥接
- 兼容传统总线

### 3.2 路由方式

**地址路由 (Address Routing)**
- Memory 和 I/O 请求使用
- 基于目标地址

**ID 路由 (ID Routing)**
- Completion 和配置请求使用
- 基于 Bus/Device/Function 地址

**隐式路由 (Implicit Routing)**
- 消息类型使用
- 广播或发送到 Root Complex

---

## 四、PCIe 配置空间

### 4.1 设备识别

每个 PCIe 设备有唯一的 16 位 ID：
```
ID = [Bus Number:8] [Device Number:5] [Function Number:3]
```

### 4.2 配置空间类型

**Type 0 - Endpoint 配置空间**
- 设备配置
- BAR (Base Address Register)
- 命令/状态寄存器

**Type 1 - Bridge 配置空间**
- 用于交换机和桥接器
- 包含总线号范围

### 4.3 BAR (Base Address Register)

- 告诉系统设备的内存/I/O 需求
- 系统分配地址空间
- 支持 32位和64位地址

---

## 五、关键概念详解

### 5.1 Posted vs Non-Posted 操作

**Posted 操作 (如 Memory Write)**
- 发送后无需等待确认
- "Fire and Forget"
- 无完成包

**Non-Posted 操作 (如 Memory Read)**
- 需要请求 + 完成包
- 读请求 → 等待 → 完成包返回数据

### 5.2 虚拟通道 (Virtual Channels)

- TC (Traffic Class) 映射到 VC (Virtual Channel)
- 不同 VC 有独立的缓冲和流量控制
- 避免不同优先级流量互相阻塞

### 5.3 中断机制

**Legacy INTx**
- 兼容传统 PCI
- 电平触发
- 需要共享和清除逻辑

**MSI (Message Signaled Interrupt)**
- 通过写特殊地址触发中断
- 无需共享中断
- 现代化方案

### 5.4 DMA / Bus Mastering

- 设备可以直接访问主存
- 需要设置 Bus Master Enable 位
- 驱动程序提供缓冲区物理地址

### 5.5 排序规则

**默认 Relaxed Ordering 关闭：**
- Posted 写入按序到达
- MSI (Posted) 在写之后到达
- 读请求不会在之前的写之前到达
- 读完成按请求顺序返回

---

## 六、TLP 数据包详解

### 6.1 Memory Write Request

```
Header: 0x40 00 00 01  (Fmt=2b010, Type=00000)
       + 00 00 00 0F  (Requester ID, Tag, Last BE, 1st BE)
       + Address      (地址, 32 or 64 bit)
+ Data: 0x12345678
```

**示例：** 写 0x12345678 到地址 0xfdaff040
```
0x40000001, 0x0000000f, 0xfdaff040, 0x12345678
```

### 6.2 Memory Read Request

```
Header: 0x00 00 00 01  (Fmt=2b000, Type=00000)
       + Requester ID, Tag, BE
       + Address
```

### 6.3 Completion TLP

- 响应读请求
- 包含 Requester ID 用于路由
- 使用 Tag 匹配原始请求
- 可能拆分为多个完成包

---

## 七、PCIe Gen6 新特性

### 7.1 关键提升

- **带宽翻倍**: 64 GT/s per lane (x16 = 256 GB/s)
- **PAM4 信号**: 4级脉冲幅度调制 (替代 NRZ)
- **FEC 前向纠错**: 引入轻量级低延迟 FEC
- **FLIT 模式**: Flow Control Unit 编码

### 7.2 PAM4 vs NRZ

| 特性 | NRZ (Gen1-5) | PAM4 (Gen6) |
|------|-------------|-------------|
| 信号电平 | 2 | 4 |
| 编码效率 | 80% (8b/10b) | 98.5% (128b/130b) |
| 噪声容忍 | 较高 | 较低 |

### 7.3 三大技术支柱

1. **PAM4  signaling** - 更高数据率
2. **FEC** - 纠错机制
3. **FLIT mode** - 流量控制单元

> ⚠️ Gen6 三者必须同时使用，缺一不可

### 7.4 LTSSM 增强

- 多相均衡 (Multi-phase Equalization)
- 升级 FIR 滤波器 (3-tap → 5-tap)
- FLIT 模式协商更早进行

---

## 八、学习要点总结

### 核心概念
1. **点对点网络** - 不是传统总线，每个链路独立
2. **三层架构** - 事务层/数据链路层/物理层
3. **TLP** - 事务层数据包，PCIe通信基本单元
4. **流量控制** - 信用机制，防止溢出
5. **无确认写入** - Posted 操作无需完成包

### 调试要点
- 使用 lspci 查看设备
- 理解 Bus/Device/Function 寻址
- 理解 TLP Header 字段含义
- 理解地址路由 vs ID 路由

### 进阶主题
- 虚拟通道和 QoS
- 多通道带宽聚合
- PCIe 切换和拓扑
- 错误处理 (AER, DPC)

---

## 九、参考资料

1. Xillybus PCIe Tutorial Part I & II
2. SNIA PCIe Webinar (Martin Chao, Broadcom)
3. SoC & FPGA PCIe Gen6 课程
4. PCI-SIG PCIe Base Specification

---

*笔记整理：小虾 🦐*
