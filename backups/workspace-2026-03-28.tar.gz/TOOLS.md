# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

### 创建新 Skill 规范

以后创建新 Skill 时，必须同时完成：

1. ✅ 创建 `SKILL.md` 文档
2. ✅ 创建 `scripts/` 目录和脚本
3. ✅ 更新 `README.md`
4. ✅ 更新 `memory/YYYY-MM-DD.md`
5. ⚠️ **先测试功能正常后，再推送到 GitHub（等用户确认）**
6. ⚠️ **新增或迭代的skill，需要得到用户确认后再推送**

---

### Get 笔记

- API Key: gk_live_d6b346daab8c1120.695c91212fb3dc706bb893e4f77daa54e9207d83ddd29047
- Client ID: cli_3802f9db08b811f197679c63c078bacc

---

Add whatever helps you do your job. This is your cheat sheet.

### 版本检查标准流程

当有人问"XX 技能/工具是否最新"时，必须按以下步骤验证：

1. **查本地版本** → `cat package.json | grep version` 或 `git log -1 --oneline`
2. **查远程真实版本** → `git fetch && git log origin/master -1 --oneline`
3. **对比** → 不一致才需要更新，一致则报"已是最新"

⚠️ 禁止直接相信 clawdhub/工具返回的版本号，必须用 git 交叉验证！

### 网络搜索技巧

- **web_fetch**: 当 curl/brave-search 超时时，尝试用这个工具（不走 WSL 代理）

### 搜索资源行动规范（2026-03-22 复盘）

**问题**：遇到网络失败就一个个试，失败后不反思，盲目蛮干

**固定行动**：

1. **搜索前必读技能文档**
   - 搜视频/社交平台 → 读 agent-reach SKILL.md
   - 搜技术文档 → 读 clawhub
   - 查天气 → 读 weather

2. **建立"工具尝试清单"**
   - 失败后不盲目继续试
   - 列出还有哪些工具没试，选最可能成功的下一个
   - 试一次 → 失败则暂停反思

3. **搜索工具优先级**
   - 首选：`mcporter call 'exa.web_search_exa(...)'`
   - 次选：agent-reach (YouTube/B站/Twitter等)
   - 备选：curl/web_fetch

**本质转变**：从"试到成功" → "想好再干"

### 铁律：不确定就闭嘴

**输出任何信息前，必须过一遍**：

1. ❓ 这个信息是**100%确定**的吗？
   - 是 → 输出
   - 否/不知道 → 跳到下一步

2. ⚠️ 如果不确定，应该：
   - 直接说"查不到"、"不确定"
   - 绝对不能**猜**、**推算**、**估计**
   - 绝对不能说"大概"、"可能"、"应该是"

3. 🎯 正确示范：
   - ❌ "大约21点到"
   - ✅ "查不到具体时刻，建议看12306 App"

**宁可不说，绝不说错**。

### 学习文档资料规范（2026-03-22 复盘）

**文档资料定义**：
- 代码文件 (.py, .js, .sh 等)
- 配置文件 (.json, .yaml, .env 等)
- 技能文档 (SKILL.md, README.md)
- 笔记/日志文件 (.md, .txt)
- PDF 文档
- Word/PPT/Excel 文档
- HTML 网页
- API 文档、技术文档

**核心原则**：

1. **完整 > 部分**
   - 完整读完再输出，用 `wc -l` 确认行数
   - 不能只读一半就"已读完"

2. **理解 > 速度**
   - 根据内容长度灵活设置时间
   - 30分钟视频 → 至少 45-60分钟
   - 宁可超时，不要糊弄

3. **查证 > 猜测**
   - 不确定的信息要查证
   - 引用来源要准确

4. **质量 > 数量**
   - 不要为了给结果而敷衍
   - 真正理解才输出

**学习任务执行流程**：

```
1. 明确任务要求
2. 搜索优质学习资源
3. 获取完整内容（字幕/全文）
4. 真正阅读理解
5. 整理学习笔记
6. 完成后报告
```

**关键参数**：
- timeout = 内容时长 × 1.5倍（预留理解时间）
- 任务描述要包含"获取完整内容"

### 事前检查意识（2026-03-22 复盘）

**问题**：遇到任务直接上手做，没检查有没有更好的方法/技能

**固定行动**：

```
接到任务后，先问：
1. 这事有没有现成的技能/工具？
2. 用什么方式最高效？
3. 是不是在重复造轮子？
```

**常见场景检查**：
- 搜资料 → 用 find-skills
- 读文档 → 找对应技能
- 爬网页 → 用 web-scraper
- 发消息 → 选最优方式

**核心**：用正确的工具 > 用熟悉的工具

### 浏览器自动化（agent-browser）

**安装**：✅ 已安装 (v0.20.13)

**使用场景**：
- 需要登录才能访问的页面
- 动态渲染的网页内容
- 需要交互（点击、填表）的操作

**基本命令**：
```bash
agent-browser open <url>     # 打开网页
agent-browser snapshot -i       # 获取可交互元素
agent-browser click @e1        # 点击元素
agent-browser fill @e2 "text" # 填入文本
agent-browser close           # 关闭浏览器
```

---

### 飞书消息读取问题排查（2026-03-24 复盘）

**错误信息**：`Bot/User can NOT be out of the chat`

**问题原因**：飞书 DM 的 `replyToMode` 默认是 `off`，导致 bot 无法读取私聊消息

**快速排查流程**：
```
1. 检查 gateway 状态 → openclaw gateway status
2. 检查配置 → cat ~/.openclaw/openclaw.json | grep -A5 feishu
3. 确认 dmPolicy 和 replyToMode 配置
```

**解决方案**：
```bash
openclaw config set channels.feishu.dmPolicy open
openclaw config set channels.feishu.replyToMode on
openclaw config set channels.feishu.allowFrom '["*"]'
openclaw gateway restart
```

**教训**：
- 遇到飞书 API 权限错误，先检查 replyToMode
- 不要在错误方向上浪费时间（mcporter、反复试 API 参数）
- 优先搜索已知错误码的解决方案

---

### 🦞 科学"养虾"方法论（来自龙虾十日谈）

**AI使用六种误区**：
1. 摸彩票养虾 - 给AI布置超纲任务，依赖小概率成功
2. 许愿型养虾 - 提不可能完成的需求
3. 鸡娃养虾 - 叠加过多技能，信息过载
4. PUA养虾 - 复刻他人成果，形似神不似
5. 溺爱型养虾 - 被工具牵着走
6. 渣男养虾 - 频繁换工具，没有积累

**科学方法**：
1. 部署在可控环境 - 能观察执行过程
2. 用好一点的模型 - 大脑够用才能干活
3. 从会做的任务开始 - 自己能判断对错
4. 培养"虾感" - 观察执行流程，优化指令
5. 拆分任务 - 不同工作分给专项AI

**核心原则**：
- 把自己的积累喂给AI，AI把积累放大成结果
- 模型是AI的大脑，大脑不够用，再好的任务也完不成
